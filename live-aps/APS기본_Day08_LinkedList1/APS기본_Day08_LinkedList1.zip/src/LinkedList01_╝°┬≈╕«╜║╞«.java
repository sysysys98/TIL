import 순차리스트.SequentialList;

public class LinkedList01_순차리스트 {
	public static void main(String[] args) {
		SequentialList sList = new SequentialList();
		
//		테스트 해볼 수 있다!
//		sList.add()
		
	}
}
