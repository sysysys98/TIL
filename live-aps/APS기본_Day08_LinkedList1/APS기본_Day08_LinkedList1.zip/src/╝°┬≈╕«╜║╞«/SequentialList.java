package 순차리스트;

//ArrayList를 생각해보면서 직접 만들어보자!
public class SequentialList {
	private String[] arr;
	private int size;
	
	public SequentialList() {
		arr = new String[10];
	}
	
	//삽입(첫번째 위치 / 중간 위치 / 마지막 위치)
	
	//조회(전부 순회하면서 출력해보기)
	
	//삭제(첫번째 위치 / 중간 위치 / 마지막 위치)
}
