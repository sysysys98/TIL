import java.util.ArrayDeque;
import java.util.Deque;

import 데크.LinkedListDeque;

public class LinkedList07_데크 {
	public static void main(String[] args) {
		LinkedListDeque<Integer> deque = new LinkedListDeque<>();
		
		//테스트는 자유롭게 진행해볼것
		deque.addFirst(10);
		System.out.println(deque.removeFirst());
		
		Deque<String> deque2 = new ArrayDeque<>();
		
		deque2.add(null);
		deque2.removeFirst();
		
	}
}
