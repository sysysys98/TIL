import 이중연결리스트.DoublyLinkedList;

public class LinkedList05_이중연결리스트 {
	public static void main(String[] args) {
		DoublyLinkedList list = new DoublyLinkedList();

		// 각자 테스트 해볼것!

	}
}
