package 원형연결리스트;

//꼭 알아야 하는것은 아니지만 머리가 너무 쿨링이 되었다..
public class CircularLinkedList {
	private Node head;
	private int size;
	
	
	//조회
	
	//삽입
	
	//삭제
}
