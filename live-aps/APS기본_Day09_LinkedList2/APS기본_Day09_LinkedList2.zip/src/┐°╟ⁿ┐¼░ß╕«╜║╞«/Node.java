package 원형연결리스트;

//필요하다면 단일도 가능 / 이중도 가능
public class Node {
	public String data;
	public Node prev; // 이전 주소
	public Node next; // 다음 주소

	public Node(String data) {
		this.data = data;
//		this.prev = null;
//		this.next = null;
	}
}
